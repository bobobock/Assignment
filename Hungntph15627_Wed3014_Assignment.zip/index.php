<?php
const BASE_URL = "http://localhost/we17101-php2/Assignment/";
require_once './vendor/autoload.php';
require_once './commons/db.php';
require_once './commons/route.php';

?>