<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="{{BASE_URL . 'admin'}}" class="brand-link">
      <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCA4ODhIODhEREQ4OEhcQEREQEREXFxIRGBcYGhoYGBcbICwkGyApHhoYMjYlKS4wMzMzGiI5PjkxPSwyMzABCwsLEA4QHhISHjIpJCowMjI0NDIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQcEBQYIAwL/xABEEAACAgECAwUDCQUGBAcAAAABAgADBAURBhIhBzFBUWETInEXMlJUYoGRobEUQpKTwRUjcoLC0TNVlOEWJDU2dLLw/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAIDBAEF/8QAKBEAAgIBBAECBwEBAAAAAAAAAAECEQMEEiExQVFxExQiMoGhsdFh/9oADAMBAAIRAxEAPwC5oiIAiIgCIiAIiIAiJEAmJEQCYkRAJiREAmJEQCYiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIkRAERNTrvEGHp1ftMq0Jv8xB1dz5Ko6n4906lZxuuWbafHIyaqhzWuqDzZgP1lQ6t2kahmMatPqapOvVVNlhXzO3RfunCZmdfexa+yyxj3l2J6/CXx08vPBnlqYrrkvvL430ino2VWxHeE3Y/lNc/abpAPR7W9RU8o2JatNEqeqkXnX2maQx6vYvqanm0wuMtKv2FeVWGPcrnlP4GeeIh6eIWpl6HqOq5LBzVsrL5qwI/KfSeZMDVcrFYNj3WVkfQY7fh3TvtB7Ub6yteo186dP72teVwPMoejD4bSmWnkuuS6Opi++C3YmDpOq42dULsWxbKz4r3qfJgeqn0MzpQaCYkRAJiIgCIiAIiIAiIgCIiAIiIAkREARE1nEGrV6fh25dnUVL7q+LOeiqPidoXIujS8b8YVaXXyJs+XYPcTwUfSb09PGcZofBmXqjnUdYtdKn9/Zjs7J3+P8Aw09JmcCcPWaje+s6l7/O5NKN3Mw/e2+iPAem81naPxk2TY+BiNti1HltdT/xnHeAfoD8z6TVFU9se/LMspWt8+vC/wBPtrPGeLp6th6HUiAe6+Tygkn7O/zviZXbuXYux3ZiWY+ZJ3Jn5iaIwUejLObl2IiJIgIiIAU7EHyO/US09C1rTtdRcLU6a0ywOWuxAE59hsOUj5p+z3SrJKMVIZSQyncEHYgjxEhOCkWQm4lgarw9qPDl37dgWNZjA++dt/c+javiPteEsfhTiWjVaPaV+7amwtqJ6o3p5j1ml7POKRqeO2Lk7NlUrs++211XdzbeJ8D93nOb4g02zhzUK9Rwgf2K1uWyody7/OT4HvHkekzNb3tl939NSagt0ft/hbsTHwsuvIprvqPNXaodD5gjeZEzmkSZEQCYiIAiIgCIiAIiIAkREAREQBK27UrHycnA0tD0vf2jgeO5Cr/rlkyqeJdSrXirFJUuKAlRUbA87cxG2/ftziWYvusqzfbXq0dBx5qq6Tpa4+P7tlq+wq271UD3m/D9ZRxnY9qGpnJ1N6wd68VRUB9rvY/p+E46a8Maj7mTPLdP2EREtKBO917gKyjS8fLqUm+uvmy6+8+9724H2QdiPSfLsz4XbNyRl3L/AOVxmDDcdLbR80fAd5+6XawBGxG4PQg+MzZc22SSNWHDui2/J5aiWN2gcCNQWzsFC1B3a2lR1rPiyjxX08JXMvhNSVoonBwdMRESRA2Gg6q+Bl1ZVZ61Puw+nWejKfiN5f2s4tWp6dYg2au+rnQ+R25lPxnnGXb2Z6t7TSGD7s2GXUgd5UDmAH5zPqI9SRq00u4s/PZNnPZgWYth9/CuNY38Eb3gPx5vwneSreyfOSzN1EKGUX8lyKfBQzg7kdN/fEtKZ8qqbNOF3BCIiVlgkyJMAREQBERAERIgCIiAIiIB+WYKCxOwA3JPgBPP2t8QLbrTagi+5XcrIv0lr2APxO0ufjO6yrS8t6gecVMOngD0J/CedJq08btmTUzapL3MjUMo3323Hvusezr4czE7THiJqSoyMTpuDeELtVsDEGvEQ/3lu3ztu9U8z+k+PDHCWbqZL0qq0odmstJCE+Q26t90tHG0fiGmtaqs3T660HKiJiEKo8gJTkyVwmrLsWK+WnR1mn4NWLSlFChKqxsqj9T6zKnFXHiXEBuZsTNROrVVo1blfHkPnOj0HWKdRxkyadwrbqyN86tx0ZGHmDMbjSvs3KS66NkRvK44x7Oa8gtkafy1XHdnp7ksP2fon8p2PEWuVadjm+0M5LBK61+dZYe5V/3mhqTibJHtfaYWGrdVpatrGUfabzkobo/UuCM9svpaspLNxLcexqr62rtToyONj/3HrPjLk1nhLWdQr5MvJ0+zb5rfsxDp/hcdRK51/hLN06xVvVDXYSEtVvcYgb7EnuPoZrhlUuDFPE4+ODQzt+AuIKcDGz1ucBrK+atDv777EbD8ZxESco7lTIQk4u0d72RZtdWoWVWdHyauWs+BZW5iv3j9JdU8waflPRfXdWSHqsV1I8wd56ax7PaVo+23Oobby3G8y6iNSs16aVxo+sREzmkREQCYiIAiIgCRJkQBERAEREAxs/GF9NlJ7rUZOvqNp5kyKjVY9bfOrcofiDtPUk8+doWF+z6vkqBstjC5fg43/XeadM+WjLqo8JnNzK0rBfLyK8evo9z8ik+cxZlaVlnGyab1OxptV9/gRv8AlNTuuDIqvkvLs5uqOmV0psLKC1dy+K2AnfcTq5yefwrVkWjPwci3ByblDO9BBWwEbjnQ9CfWfD/w1rX/ADq3/p6v9p572t3Z6MW0qo7F2CgsxAUDcknYADxJle8J4+XkWZ+TgZCUYl2bY1YakOH26Fl6jYTPbg3MyPc1DVcm+jf3qq1SoOPJivhOswcSrHqSmlQlVShURe5QP/3fO2orh2KcnzwcLxFTk4udpuTqGQt2LXklWYVci1uykIzdT47fhLBBBG47j3GYupYFOXS2PkILKrBsyn9QR1BHmJyycHZ1A5MLV8mqgfMrsSu3kHkGPhOWpJW6FOL45O1nFdqV1f8AZhpbZrrnUUoPnFgdyQPQT9f+Gta/51b/ANPV/tPlk8N1YFGTqGVfbmZiUuFuyD0r3Xb3E7hOxUU07Em2mqKQIiInonmGy4bwTlZ+NR4W2qD/AIQd2/IGelFAA2HcOg+EpXshwPa6i95Hu41JIP27Dyj8uaXXMOof1Ub9MqjYiIlBoEREASZEmAIiIAkSZEAREQBERAEqTtnweW3FygOliPSx9VIZfyLfhLbml4n0GrU8Rsazod+epx312DfZh+JBHkZPHLbJNleWO6LR5yiZ+taPkafe1GQhV17j+66/SU+ImfpHCGoZ1S3Y9QapyVDl1A3B2O/l1nobklZ521t1Rc3AOf8AtOlY7k7siezb/EnSdHKi4L1TI0PJbT9SRqqLm3rsb5q2eYbuKn8pbakEbjqD1BHjMGSO2R6OKW6PsfqIiVlgiIgCcF2taoKNPGMD/eZTcu3j7NerH9B987XNy6sep77mCVVqWdmPQAShOIdQytczrLqa7HrrUitFBPs6V8W8AT3n/tLsMblb6RTnnUaXbObiNpveFOGMjVLglYKUqf720joi+Q829JtbSVs89Jt0iy+x/A9lp75BHvZNp2P2EHKPz5p38w9MwKsSivGpHLXUoVR/U+pmZPOnLdJs9SEdsUhERIkhERAEmRJgCIiAJEmRAEREAREQBERANNxHw5janWteQGArbmVkIDfDfymRomj4+nUDGxlK1glveYklj3kkzYxO26o5SuzFzsCjJrNd9aWVnvV1BmJp2k/sg5MexxSO6mw86oPJCeoHpvtMnUNSx8ROfItStfN2A3+AnKr2hY1+SmJgVWZNtrcoY+4gHiST12HwnYxk+iMpRT57O2iB6984/izjvG0x/YBGvyNgWRSAEB7uZvA+k5GLk6RKUlFWzsInC8Odo+Jm2exvQ4thBKl3BRtupHN02Pxmbq/H+mYyN7O5brQPdSvcgnyLDoJL4crqiKyRauzI1nhf+0XH7bkWNQp3XHq2RP8AMe9jOa401jC0fEbTtPREyLRysK9t60PeWP0j4CaDXu07MyENeIgxkYbGzfmt+49y/HvmBwfwXkaq/t7WKYxbd7C272HfqB47+pl0YUrm+PQolkt1jXPqfbs94OXU2tuyQ64tY5VKnYvafI+QHf8AES4tG0qnBx0xqQeSsbbnbdjvvuT4mfbT8GnFpSihQlVS8qqPL+pmVKsmRzf/AAux41BCIiVlgiIgCIiAJMiTAEREASJMiAIiIAiIgCInztsVFLuQqKCzMTsAB3kwCXdUUs5AVRuWYgAAeJJ7pWPFXaaqFqNNAYjcHIYe7v8AYXx+JnPcecavqDtjYzFMJDsduhuI8T9nyE4qa8WDzIx5dR4iZGdn35NhtyLHssPXmdifw8pbHZPw77Cg6hcNrckbUhh1Wnf53+Y/lt5yv+CtB/tLPSlulKf3lvXvQH5o+M9CVoqKFUAKoCqB3AAbACczzpbUNPC3vZ+5QnaRpV+Pqd1tisacl/aV2bHlIIG6b+BG3d5bS+58rqksXldVdT3qyhgfuMpx5Njs0Zce9UecuHNBv1PJWilTyk72W8pKVr4sx/QeMsXF7JMcbe2yrHHiERV/M7yyKMeupeWtFRfooqqPwE+snPPJ9cEIaeKXPJRvaHwimltVZjc5x7ByEsSStg8z6j9JzWka3l4NgsxrXQ+K77q3oV7jL74v0lc/T76Dtz8hsrY/u2J7ynfw6jb4EzzpLsMt8aZnzR2StF08JdotGYVozeWjIbZVffauxvLc/NPoZ308sSz+zvjllZdPz2JU7JRc56g+COfLyMry4K5iW4s98SLYiImY1CIiAIiIAkxEAREQBERAIiIgCIiAJVXaxxMQRplDbDYPksp79+q1/wBT90srU8xcbHtvb5tKFz67DoPxnmrOy3yLrL7Du9zl2J8yd5fp4W79DPqJ0qXk+ERE2mA+2FmW49i20u1dqHdWU7ES4eDO0KrM5cbOK1ZR6K/dXaf9LencfCUxEhPGprksx5XDo9TxOH7LM3KyNPZsiw2KlhSot1YIAOhPj1853EwSW10ejGW5WJj5uXVj1Ndc611VjdnY7ACZEpHtXzMo6i2PZYTjIiPVWOigMOpYeJ3B6mdxw3uiOSeyNkcacfW5xbHxC1WH3E9z2j7XkvpOHiJ6EYqKpHnSk5O2IEROkS7uzLic5+Mca9t8rFA6nvsp7lb4g9D93nO5nnHhHVWwNQoyAdkD8lg8636MP6/dPRikEAjqD1B8xMOaG2XHk9HBPdHnwfqIiUlwiIgExEQBERAEREASJMiAIiIBxnanlmnSXUd9zqn3b7mUXPQ/GHDY1WhKDYagj8+4XffpttON+SNPrbfyxNWHJGMaZkzYpSlaKqiWt8kafW2/gEj5I0+tt/LEt+PD1Kvl5+hVUS1fkkT6238sR8kafW2/liPjwHy8/Q4PhviTL0y32lD7oT79T78jj1HgfUS7eGuKsXVKealuS5QPaUsRzJ6/aX1H5TjvkjT6238sT6VdlJrbmrzrEbYjmROU7HvG4MpyPHPm+S3HHLD2MzjPtCrxObGwSLckbq9nfXUf9TencJT+XlW32Nbc7WWud2dzuSZaHyRJ9bb+AR8kafW2/liShPHBcHMkMs3yVVEtX5I0+tt/LEfJGn1tv5Ylnx4Ffy8/QqqJavyRp9bb+AR8kifW2/liPjw9R8vP0Kqno/hTLORpuLae9qVB+IHL/ScN8kafW2/gE73h3Sv2DDqxOc2eyBHORtvuSe6UZskZrgvwY5Qbs2kREzmkSZEmAIiIAiIgCIiAIiIBESZEAREQBNNxTq66fg3ZRI50XasH9609FG3x/LebmVN2r6sbsujTqla1KNr7q61LFmPcuw8k3P8Amk8cd0kiGSW2Nm37O+LcrNutxc9lN4RbavcVCyfvDYd/gfvmx7SNcytOxabcRlWx7xWxZFbdeRjtsfUCV5qXELrqWNqVeJdiigJW4sVgr1jpt1AG/LvOs7W70t03EtrYNXZkI6sO4qUYgy1wW+PHZTveySvlGPZqnFuNV+1W1020qoZlC1H3D132Qhh0nR43FYzNFvz8YezvpqfmRtm9ncq7+Pzl7iD4ibGzXMLGw1ttuq5EqXcB0YseUe6FB6kyveEaH/sTWMjYrVkB/Zqe73Vbfb+ID7pFVJW1XKJO4uk74ZvOznjSzUHfFzXU5AHtK3AVfaJ+8vKOm6/ofSa7I4/yb9ZrxsN0GF7Vad+RWNvX3nDEdAfDbwG/jNNicM25GjYufghhmVO6MKyQzo1hQEEeI36+m8ytT0NNMztFxl2Nm7Na4Hz7C6b/AHDuHpLNsLf5/RBSntX459zrNf4gy6NcwcGp1GPkcvtVKKSd+fuY9R3CavjDjTL03Vq6lKthiut7K+ROZgxYNs56g9B+EcV/+6NM/wAv62TH4hw6snimqi1eaq3GVWHps8jFLi14ZKblzT8nScYcRvTpH7fgWLuzV8j8quOVm2I2PTebzh/KsyMLHutINltSO5A23Yjr0HdKX4kry9KryNHt5nxLnS7Gc77KFfmPL8e4jz6+MuLhP/0zE/8Aj1//AFkZwSj+f0ShNyk/b9m4iIlJcIiTAEREAREQBERAEREAREQBERAIiTEAic9pnCmNjZ12oc9tuTkc3MbShCcx68gVRt0AHwE6GJ1No40n2a3XNIp1DGfFv5vZ2bHmQgMrA7hlJBG80+ZwTi36fRp1t2QacV+at+evn294BSeTYgBth08BOqiFJro44p9nB4/ZZpSMGdsi0D9x7FCn48qg/nOsydKpsw3wVX2dDVGkLXsOVCNvd3G02ETrnJ9sKEV0jWaBo1WnYqYlLO9dZYhrCpY8xJO5AA8fKYuscM4+blY2Xa9q2YZJRa2UK25B94FST3eBE3sTm53Z3aqo0WocM4+Tn0ajY1ouxduRVZQh23+cCu/j5xfwzj2akmpl7RfWgQKCvIQN+8cu/j5zexO7mc2o03EfD2LqtIpyQw5G5kesgOjeOxII6joQRM7TsRMbHrx0LFKUFaliNyFG3XbxmXE5bqjtK7ESYnDoiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIBESYgERJiAREmIBESYgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgH//Z"
      alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">Admin</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <!-- <div class="image">
          <img src="https://i.pinimg.com/originals/ba/1d/37/ba1d3778a33091a234236774a78151e7.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">Đầu cắt moi</a>
        </div> -->
      </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item ">
            <a href="#" class="nav-link ">
              <i class="nav-icon fas fa fa-tasks"></i>
              <p>
                Sản phẩm
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{BASE_URL . 'them-sp'}}" class="nav-link ">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Thêm sản phẩm</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{BASE_URL . 'danh-sach-sp'}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Danh sách sản phẩm</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item ">
            <a href="#" class="nav-link ">
              <i class="nav-icon fas fa fa-list"></i>
              <p>
                Danh mục sản phẩm
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{BASE_URL . 'them-dm'}}" class="nav-link ">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Thêm danh mục</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{BASE_URL . 'danh-sach-dm'}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Danh sách danh mục</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item ">
            <a href="#" class="nav-link ">
              <i class="nav-icon fas fa fa-user"></i>
              <p>
                Tài khoản
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{BASE_URL . 'tao-tk'}}" class="nav-link ">
                  <i class="far fa fa-user nav-icon"></i>
                  <p>Thêm tài khoản</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{BASE_URL . 'danh-sach-tk'}}" class="nav-link">
                  <i class="far fa fa-user nav-icon"></i>
                  <p>Danh sách tài khoản</p>
                </a>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>